# Weekend Trip Planner Agent (T9)

An agent that plans a short trip by calling tools and deciding what fits,
rather than just answering a question in one shot.

## How this meets the brief

| Requirement | Where it lives |
|---|---|
| One agent with a plan-act loop (more than one step) | `run_turn()` in `agent.py` — it calls the model, executes any tools the model asks for, feeds the results back, and repeats until the model gives a final answer. A single request like "plan a 2-day Paris trip with a museum, a landmark, and a food stop" takes several tool calls in a row. |
| At least two tools | `find_activities(city)` and `add_to_itinerary(day, activity_name, city)` in `tools.py` — plain Python functions. |
| Memory across turns | Two layers: the full `messages` list is carried from one user message to the next (conversation memory), and `tools.ITINERARY` holds the trip itself at the process level, so it survives independently of what's in the chat window. |
| Agentic, not a chatbot | The agent decides *which* day to try, and what to do when `add_to_itinerary` rejects a request (try another day, or tell the user it doesn't fit) — that decision isn't hardcoded, the model makes it from the tool's response. |
| Group add-on: rough timing + overpacked flag | `add_to_itinerary` computes a start/end time for each activity (days start at 09:00, with a 30-minute buffer between stops) and returns `overpacked: true` once a day passes 8 scheduled hours, which the agent is instructed to flag to the user. |

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Pick a free lane and set the matching environment variable(s):

   **GitHub Models** (simplest — a GitHub account is all you need):
   - Create a token at https://github.com/settings/tokens with the "models" permission (or use the token GitHub Models gives you in the marketplace page for a model).
   - `export GITHUB_TOKEN=your_token_here`

   **Microsoft Foundry**:
   - Deploy a chat model in your Foundry project and grab its endpoint + key.
   - `export AZURE_AI_ENDPOINT=https://your-endpoint`
   - `export AZURE_AI_KEY=your_key_here`
   - Optionally `export AZURE_AI_MODEL=your-deployment-name` (defaults to `gpt-4o-mini`).

3. Run it:
   ```
   python agent.py
   ```

## Example session

```
You: Plan a 2-day trip to Paris — I want a museum and a landmark each day.
Agent: Day 1: Louvre Museum (09:00–13:00), Eiffel Tower Visit (13:30–16:00).
Day 2: Musee d'Orsay (09:00–12:00), Montmartre Walk (12:30–14:30).
Both days have plenty of room left if you want to add more.

You: Add the Versailles Day Trip to day 1 too.
Agent: Versailles (6.5h) doesn't fit what's left on Day 1, so I put it on
Day 2 instead (14:30–21:00). Heads up — Day 2 is now pretty packed at
9.5 hours of activity.

You: reset
Agent: Started a new trip.
```

## Swapping in real data

`tools.CATALOG` is a small mock dataset for four cities (Paris, Tokyo, New
York, Lisbon). To use real activity data, replace the body of
`find_activities()` with a call to a real places/events API — the return
shape (`{"city": ..., "activities": [{"name", "category", "hours"}, ...]}`)
is the only contract the rest of the agent depends on.
