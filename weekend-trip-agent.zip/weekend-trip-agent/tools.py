"""
Tools available to the trip-planning agent.

Both `find_activities` and `add_to_itinerary` are plain Python functions —
the agent calls them the same way it would call any other API. `ITINERARY`
is module-level state, so it persists for the whole run: it's the agent's
"memory of the trip built so far", separate from (and in addition to) the
conversation history the agent also remembers.

`add_to_itinerary` does the mechanical work (timing math, hard physical
limit) but deliberately does NOT decide which day to try or what to do if a
day is full — that decision is left to the agent. If a call is rejected,
the agent is expected to read the reason, decide whether to try a different
day or tell the user it doesn't fit, and act on that decision itself.
"""

from typing import Dict, List, Optional

DAY_START_HOUR = 9.0     # the itinerary day starts at 09:00
HARD_CAP_HOURS = 11.0    # a day cannot physically hold more activity time than this
SOFT_CAP_HOURS = 8.0     # beyond this, a day is considered "overpacked"
BUFFER_HOURS = 0.5       # travel/rest buffer between back-to-back activities

# Mock activity catalog. Swap this for a real activities/events API later —
# nothing else in the agent needs to change, since the tool's contract
# (name, category, hours in -> success/fit info out) stays the same.
CATALOG: Dict[str, List[dict]] = {
    "paris": [
        {"name": "Louvre Museum", "category": "Museum", "hours": 4.0},
        {"name": "Eiffel Tower Visit", "category": "Landmark", "hours": 2.5},
        {"name": "Seine River Cruise", "category": "Leisure", "hours": 1.5},
        {"name": "Montmartre Walk", "category": "Neighborhood", "hours": 2.0},
        {"name": "Le Marais Cafe Crawl", "category": "Food", "hours": 1.5},
        {"name": "Musee d'Orsay", "category": "Museum", "hours": 3.0},
        {"name": "Versailles Day Trip", "category": "Excursion", "hours": 6.5},
    ],
    "tokyo": [
        {"name": "Senso-ji Temple", "category": "Landmark", "hours": 2.0},
        {"name": "Shibuya Crossing & Shopping", "category": "Neighborhood", "hours": 3.0},
        {"name": "Tsukiji Outer Market Food Tour", "category": "Food", "hours": 2.5},
        {"name": "teamLab Planets", "category": "Art", "hours": 2.0},
        {"name": "Meiji Shrine & Harajuku", "category": "Neighborhood", "hours": 3.0},
        {"name": "Tokyo Skytree", "category": "Landmark", "hours": 2.0},
        {"name": "Nikko Day Trip", "category": "Excursion", "hours": 7.0},
    ],
    "new york": [
        {"name": "Metropolitan Museum", "category": "Museum", "hours": 3.5},
        {"name": "Central Park Walk", "category": "Leisure", "hours": 2.0},
        {"name": "Statue of Liberty Ferry", "category": "Landmark", "hours": 3.0},
        {"name": "Broadway Show", "category": "Theater", "hours": 3.0},
        {"name": "High Line + Chelsea Market", "category": "Neighborhood", "hours": 2.5},
        {"name": "Brooklyn Bridge Walk", "category": "Landmark", "hours": 1.5},
        {"name": "MoMA", "category": "Museum", "hours": 2.5},
    ],
    "lisbon": [
        {"name": "Belem Tower & Monastery", "category": "Landmark", "hours": 3.0},
        {"name": "Alfama Walking Tour", "category": "Neighborhood", "hours": 2.0},
        {"name": "Tram 28 Ride", "category": "Leisure", "hours": 1.5},
        {"name": "LX Factory", "category": "Neighborhood", "hours": 2.0},
        {"name": "Sintra Day Trip", "category": "Excursion", "hours": 7.0},
        {"name": "Fado Dinner Show", "category": "Food", "hours": 2.5},
        {"name": "Oceanario de Lisboa", "category": "Museum", "hours": 2.0},
    ],
}

# The agent's memory of the itinerary built so far this session.
# Shape: { 1: [ {name, category, hours, start, end}, ... ], 2: [...] }
ITINERARY: Dict[int, List[dict]] = {}


def _day_total_hours(day: int) -> float:
    acts = ITINERARY.get(day, [])
    if not acts:
        return 0.0
    return acts[-1]["end"] - DAY_START_HOUR


def find_activities(city: str) -> dict:
    """
    Tool 1. Look up candidate activities for a city.

    Returns the raw activity list (name / category / duration in hours) so
    the agent can reason about what to add and where it might fit.
    """
    key = city.strip().lower()
    activities = CATALOG.get(key)
    if activities is None:
        return {
            "error": f"No activities found for '{city}'.",
            "available_cities": sorted(CATALOG.keys()),
        }
    return {"city": key, "activities": activities}


def add_to_itinerary(day: int, activity_name: str, city: str) -> dict:
    """
    Tool 2. Attempt to add one activity to one day of the itinerary.

    Returns success + rough start/end timing and an "overpacked" flag when
    it succeeds, or success=False + a reason when it doesn't fit — the
    agent decides what to do next in either case.
    """
    key = city.strip().lower()
    activities = CATALOG.get(key, [])
    match = next(
        (a for a in activities if a["name"].lower() == activity_name.lower()), None
    )
    if match is None:
        return {
            "success": False,
            "reason": f"'{activity_name}' is not a known activity in {city}.",
        }

    day_acts = ITINERARY.get(day, [])
    current_total = _day_total_hours(day)
    buffer = BUFFER_HOURS if day_acts else 0.0
    projected_total = current_total + match["hours"] + buffer

    if projected_total > HARD_CAP_HOURS:
        return {
            "success": False,
            "reason": (
                f"Day {day} already has {current_total:.1f}h scheduled; adding "
                f"{match['name']} ({match['hours']}h) would push it to "
                f"{projected_total:.1f}h, past the {HARD_CAP_HOURS}h physical limit "
                f"for one day. Try a different day."
            ),
            "day_total_hours": round(current_total, 1),
        }

    start = DAY_START_HOUR if not day_acts else day_acts[-1]["end"] + BUFFER_HOURS
    end = start + match["hours"]
    entry = {**match, "start": start, "end": end}
    ITINERARY.setdefault(day, []).append(entry)

    return {
        "success": True,
        "day": day,
        "added": entry,
        "day_total_hours": round(projected_total, 1),
        "soft_cap_hours": SOFT_CAP_HOURS,
        "overpacked": projected_total > SOFT_CAP_HOURS,
        "full_itinerary_for_day": ITINERARY[day],
    }


def reset_itinerary() -> None:
    """Not exposed to the model — a CLI convenience to start a fresh trip."""
    ITINERARY.clear()
