"""
Weekend Trip Planner agent.

Shape required by the assignment:
  - One agent with a plan-act loop (run_turn keeps calling the model and
    executing whatever tools it asks for, in sequence, until the model is
    ready to answer the user — more than one step per request).
  - At least two tools the agent calls (find_activities, add_to_itinerary
    in tools.py).
  - Memory: `messages` carries the full conversation across turns, and
    tools.ITINERARY carries the trip itself across turns.

Works with either free lane from the course:
  - GitHub Models: set GITHUB_TOKEN (a GitHub personal access token with
    the "models" permission — see https://github.com/marketplace/models).
  - Microsoft Foundry: set AZURE_AI_ENDPOINT and AZURE_AI_KEY.
"""

import json
import os

from openai import OpenAI

from tools import add_to_itinerary, find_activities, reset_itinerary

MAX_STEPS_PER_TURN = 6  # guard rail so a confused loop can't run forever

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "find_activities",
            "description": (
                "Look up candidate activities and their typical duration "
                "(in hours) for a city."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {
                        "type": "string",
                        "description": "City name, e.g. 'Paris'.",
                    }
                },
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "add_to_itinerary",
            "description": (
                "Add one activity to one specific day of the itinerary. "
                "Fails with a reason if that day doesn't have room — read "
                "the reason and decide whether to try a different day or "
                "tell the user it doesn't fit."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "day": {
                        "type": "integer",
                        "description": "Which day of the trip, starting at 1.",
                    },
                    "activity_name": {"type": "string"},
                    "city": {"type": "string"},
                },
                "required": ["day", "activity_name", "city"],
            },
        },
    },
]

AVAILABLE_FUNCTIONS = {
    "find_activities": find_activities,
    "add_to_itinerary": add_to_itinerary,
}

SYSTEM_PROMPT = """You are a weekend trip planning agent.

You have two tools: find_activities(city) and add_to_itinerary(day, activity_name, city).

Rules you must follow:
- Before adding anything, know how many days the trip is and what's already
  scheduled on each day (you'll see this in prior tool results this
  conversation — that's your memory of the trip so far).
- Each day starts at 09:00. add_to_itinerary will reject an activity if the
  day is already too full (past its hard physical limit) — if that
  happens, decide yourself whether another day has room and try that day,
  rather than giving up immediately.
- If add_to_itinerary succeeds but returns overpacked: true, tell the user
  that day is now packed and let them decide whether to move something.
- Never invent activities or timings yourself — get them from the tools.
- Once you're done acting for this request, reply to the user in plain,
  friendly language: what got added, when (use the start/end times from
  the tool results), and flag any overpacked day.
"""


def get_client():
    """Pick whichever free lane the user has configured."""
    github_token = os.environ.get("GITHUB_TOKEN")
    if github_token:
        client = OpenAI(
            base_url="https://models.inference.ai.azure.com",
            api_key=github_token,
        )
        model = os.environ.get("GITHUB_MODEL", "gpt-4o-mini")
        return client, model

    azure_endpoint = os.environ.get("AZURE_AI_ENDPOINT")
    azure_key = os.environ.get("AZURE_AI_KEY")
    if azure_endpoint and azure_key:
        client = OpenAI(base_url=azure_endpoint, api_key=azure_key)
        model = os.environ.get("AZURE_AI_MODEL", "gpt-4o-mini")
        return client, model

    raise RuntimeError(
        "No model configured. Set GITHUB_TOKEN for GitHub Models, or "
        "AZURE_AI_ENDPOINT + AZURE_AI_KEY for Microsoft Foundry."
    )


def run_turn(client, model, messages):
    """
    The plan-act loop for a single user message: call the model, and if it
    asks for tools, run them and feed the results back, repeating until the
    model responds with a final answer (or we hit the step guard rail).
    """
    for _ in range(MAX_STEPS_PER_TURN):
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            tools=TOOLS,
            tool_choice="auto",
        )
        message = response.choices[0].message
        messages.append(message.model_dump(exclude_none=True))

        if not message.tool_calls:
            return message.content

        for call in message.tool_calls:
            fn = AVAILABLE_FUNCTIONS[call.function.name]
            args = json.loads(call.function.arguments or "{}")
            result = fn(**args)
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.id,
                    "name": call.function.name,
                    "content": json.dumps(result),
                }
            )

    return "I hit my step limit working on that — try rephrasing or ask me to continue."


def main():
    client, model = get_client()
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    print("Weekend Trip Planner agent.")
    print("Try: \"Plan a 2-day trip to Paris\" then \"Also add the Louvre.\"")
    print("Type 'reset' for a new trip, 'quit' to exit.\n")

    while True:
        user_input = input("You: ").strip()
        if not user_input:
            continue
        if user_input.lower() in {"quit", "exit"}:
            break
        if user_input.lower() == "reset":
            reset_itinerary()
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            print("Agent: Started a new trip.\n")
            continue

        messages.append({"role": "user", "content": user_input})
        reply = run_turn(client, model, messages)
        print(f"\nAgent: {reply}\n")


if __name__ == "__main__":
    main()
